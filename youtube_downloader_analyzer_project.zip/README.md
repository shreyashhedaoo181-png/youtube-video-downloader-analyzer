# 🎬 YouTube Video Downloader + Analyzer (Python Project)

A simple Python application that downloads YouTube videos and analyzes the description.

## Features
- Downloads video in highest resolution
- Extracts metadata (title, author, views, length)
- Analyzes description text
- Finds top keywords

## How to run
```
pip install -r requirements.txt
python app.py
```

Enter a YouTube URL and the video will download + analyze automatically.
